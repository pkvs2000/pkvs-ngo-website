PKVS NGO WEBSITE
================

Files:
- index.html : main website
- style.css  : complete responsive design
- script.js  : mobile menu + year
- logo.jpg   : uploaded PKVS logo

FREE HOSTING:
1. Create a free account on GitHub.
2. Create a new public repository, e.g. pkvs-ngo-website.
3. Upload all four files.
4. Repository Settings -> Pages -> Deploy from branch -> main -> /root.
5. Save. GitHub will give you a free website address.

Alternative: Netlify or Cloudflare Pages can also host these files free.

IMPORTANT:
- Replace the testimonial text if it is not an actual verified testimonial.
- Before publishing, verify all registration numbers, dates, phone numbers and email address.
- A custom .org.in domain may require paid domain registration; the hosting itself can be free.
